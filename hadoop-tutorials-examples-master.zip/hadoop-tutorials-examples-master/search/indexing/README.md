Blog URL
========

Dynamic search dashboards with Solr
http://gethue.com/hadoop-search-dynamic-search-dashboards-with-solr/

How to index
http://gethue.com/index-and-search-data-with-hadoop-and-solr

