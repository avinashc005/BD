show tables;

select count(*) from sample_07;