Blog URL
========

[How to access Hive in Pig with HCatalog in Hue](http://gethue.tumblr.com/post/56804308712/hadoop-tutorial-how-to-access-hive-in-pig-with)

