
use test;

create table stats (             
  funny int,     
  useful int,     
  cool int,     
  stars int
);

