Blog URL
========

[How to create example tables in HBase](http://gethue.tumblr.com/post/58181985680/hadoop-tutorial-how-to-create-example-tables-in-hbase) | [HBase tables](hbase-tables)

