Blog URL
========

http://gethue.com/bay-area-bikeshare-data-analysis-with-search-and-spark-notebook

