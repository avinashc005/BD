Blog
====

[How to use the Livy Spark REST Job Server API for sharing Spark RDDs and contexts](http://gethue.com/how-to-use-the-livy-spark-rest-job-server-api-for-sharing-spark-rdds-and-contexts/)

Read more on:
http://gethue.com/spark/

