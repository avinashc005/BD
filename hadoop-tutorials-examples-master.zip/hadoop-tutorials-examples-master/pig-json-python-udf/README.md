Blog URL
========

[Prepare the data for analysis with Pig and Python UDF](http://gethue.tumblr.com/post/60376973455/hadoop-tutorials-ii-1-prepare-the-data-for-analysis)
